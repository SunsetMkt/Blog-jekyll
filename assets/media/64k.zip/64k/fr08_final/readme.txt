.fr-08
.the product
.final version 1.01

a demo in 64k by farbrausch consumer consulting in 2000

Requirements:
- a fast pc, at least a p2-350
- a fast graphics card, at least a tnt2, but GeForce or
  higher is recommended
  (party version, untested on non-nvidia cards)
- a sound card
- 128MB of RAM are recommended
- DirectX 8 installed (get it at http://www.microsoft.com/directx)


Brought to you by the following loyal Farbrausch Employees:

- Chaos
  main demo and tool code, making it all possible

- Fiver2
  Concept, graphics, 3D, design, content and choreography

- KB [th]
  Audio programming, music, additional demo code

- Doj
  Additional tool code, quality assurance

- Yoda [fb]
  Additional demo code

- Ryg [fg]
  compression technology supervisor



This is the final version you've been waiting for so long. We
apologize for the delay, but we wanted to test this on as much
configurations as possible before releasing it to the public
(plus, we had to make space for the bugfixes, the icons, and
of course the hidden part while still being <64kb).

You can find us at:

the product:  http://www.theproduct.de
farbrausch:   http://www.farb-rausch.com
or in german: http://www.farb-rausch.de

Direct common questions, admire et al to fanmail@farb-rausch.de
Bug reports go to hotline@farb-rausch.de (only if they ARE bugs,
we CAN'T and WON'T help you with f**ked up drivers or similar
things)

kb and ryg signing off.


ALL CONTENTS IN THIS ARCHIVE ARE (C) 2000-01 FARB-RAUSCH CONSUMER CONSULTING,
GERMANY. COPYING AND DISTRIBUTION ARE ALLOWED AS LONG THE ORIGINAL CONTENTS
OF THE ARCHIVE REMAIN UNCHANGED AND YOU DON'T CHARGE ANY FEE FOR COPYING
OR DISTRIBUTION OF THIS ARCHIVE. THE CONTENT IS PROVIDED AS-IS, WITHOUT
ANY WARRANTY CONCERNING FUNCTION OR HARMLESSNESS. FARB-RAUSCH CONSUMER
CONSULTING CAN NOT BE MADE LIABLE FOR DAMAGES INCURRING DUE TO USE OF
THE CONTENT.

(amen)
